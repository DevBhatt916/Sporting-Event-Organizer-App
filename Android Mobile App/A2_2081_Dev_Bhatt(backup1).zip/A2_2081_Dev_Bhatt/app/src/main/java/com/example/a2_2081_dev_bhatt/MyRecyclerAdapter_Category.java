package com.example.a2_2081_dev_bhatt;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class MyRecyclerAdapter_Category extends RecyclerView.Adapter<MyRecyclerAdapter_Category.CustomViewHolder> {


    //Arraylist to hold category data
    ArrayList<Category> data = new ArrayList<Category>();

    //Method to set data for the adapter
    public void setData(ArrayList<Category> data) {
        this.data = data;
    }




    // ViewHolder class to hold references to views within each item
    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_card_layout, parent, false);
        CustomViewHolder viewHolder = new CustomViewHolder(v);
        return viewHolder;
    }

    //Constructors to initialize views
    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.tvCategoryID.setText((data.get(position).getCategoryID()));
        holder.tvCategoryName.setText(data.get(position).getCategoryName());
        holder.tvCategoryCount.setText(String.valueOf(data.get(position).getEventCount()));
        if(data.get(position).getIsActive()) {
            holder.tvIsActive.setText("Active");
        } else {
            holder.tvIsActive.setText("Inactive");
        }
    }

    //method to determine number of items in data set
    @Override
    public int getItemCount() {
        if (this.data != null) { // if data is not null
            return this.data.size(); // then return the size of ArrayList
        } else {
        // else return zero if data is null
        return 0;
        }
    }





    // ViewHolder class to hold references to views within each item
    public class CustomViewHolder extends RecyclerView.ViewHolder {

        public TextView tvCategoryID;
        public TextView tvCategoryName;
        public TextView tvCategoryCount;
        public TextView tvIsActive;

        // Constructor to initialize views
        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryID = itemView.findViewById(R.id.cv_eventId);
            tvCategoryName = itemView.findViewById(R.id.cv_EventName);
            tvCategoryCount = itemView.findViewById(R.id.cv_CategoryId);
            tvIsActive = itemView.findViewById(R.id.cv_IsActive);
        }
    }

}
